#!/bin/bash

wget http://aass.oru.se/Research/Learning/data/tutorials/localization.bag
