^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sdf_tracker
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.30 (2015-10-09)
-------------------

1.0.29 (2015-10-08)
-------------------
* removed outdated opencv2 dependency
* Contributors: Todor Stoyanov

1.0.28 (2014-12-05)
-------------------

1.0.27 (2014-12-05)
-------------------

1.0.26 (2014-12-03)
-------------------

1.0.25 (2014-12-01)
-------------------

1.0.24 (2014-11-25)
-------------------

1.0.23 (2014-11-25)
-------------------

1.0.20 (2014-11-21)
-------------------
* fixing problems with compatibility
* Contributors: Todor Stoyanov

1.0.18 (2014-04-09)
-------------------
* fixes for backward support and compatibility on new ubuntu versions
* Contributors: Todor Stoyanov

1.0.15 (2014-01-09)
-------------------

1.0.13 (2014-01-09)
-------------------
* trying to add backward compatibility for rosbuild
* Contributors: Todor Stoyanov

1.0.12 (2013-12-03)
-------------------
* Added catkinized sdf tracker in hydro
* Contributors: Todor Stoyanov
