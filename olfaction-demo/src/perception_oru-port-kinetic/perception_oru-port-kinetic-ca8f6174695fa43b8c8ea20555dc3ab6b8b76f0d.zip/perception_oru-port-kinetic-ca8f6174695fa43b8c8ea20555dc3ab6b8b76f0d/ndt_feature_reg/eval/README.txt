This directory contains all the required scripts to run the evaluation used in the paper: 'Real Time Registration of RGB-D Data using Local Visual Features and 3D-NDT Registration'.

In order to run everything (this will: 1) download quite a bit of data from TUM, 2) takes a lot of time and 3) will not show anything cool on the screen during the process) type:
sh ./run_evaluation.sh
