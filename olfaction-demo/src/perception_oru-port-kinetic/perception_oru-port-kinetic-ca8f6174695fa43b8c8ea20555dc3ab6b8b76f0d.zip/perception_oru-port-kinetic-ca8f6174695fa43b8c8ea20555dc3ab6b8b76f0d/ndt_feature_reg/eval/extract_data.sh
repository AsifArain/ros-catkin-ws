# Unpack
tar xvfz rgbd_dataset_freiburg1_xyz.tgz
tar xvfz rgbd_dataset_freiburg1_rpy.tgz
tar xvfz rgbd_dataset_freiburg1_360.tgz
tar xvfz rgbd_dataset_freiburg1_floor.tgz
tar xvfz rgbd_dataset_freiburg1_desk.tgz
tar xvfz rgbd_dataset_freiburg1_desk2.tgz
tar xvfz rgbd_dataset_freiburg1_room.tgz
