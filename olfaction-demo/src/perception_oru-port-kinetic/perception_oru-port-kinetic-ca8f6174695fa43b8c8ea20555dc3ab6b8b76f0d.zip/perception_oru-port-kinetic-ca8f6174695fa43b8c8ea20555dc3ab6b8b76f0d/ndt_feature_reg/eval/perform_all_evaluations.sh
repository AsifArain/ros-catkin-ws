# Generate results for all the data
cd rgbd_dataset_freiburg1_xyz
sh ../groundtruth_comparision.sh
cd ../rgbd_dataset_freiburg1_rpy
sh ../groundtruth_comparision.sh
cd ../rgbd_dataset_freiburg1_360
sh ../groundtruth_comparision.sh
cd ../rgbd_dataset_freiburg1_floor
sh ../groundtruth_comparision.sh
cd ../rgbd_dataset_freiburg1_desk
sh ../groundtruth_comparision.sh
cd ../rgbd_dataset_freiburg1_desk2
sh ../groundtruth_comparision.sh
cd ../rgbd_dataset_freiburg1_room
sh ../groundtruth_comparision.sh
cd ..
