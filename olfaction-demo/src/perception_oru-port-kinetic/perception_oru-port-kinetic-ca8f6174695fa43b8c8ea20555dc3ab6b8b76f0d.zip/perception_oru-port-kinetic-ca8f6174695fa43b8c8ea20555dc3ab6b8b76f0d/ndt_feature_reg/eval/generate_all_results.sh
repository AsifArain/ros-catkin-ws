# Generate results for all the data
cd rgbd_dataset_freiburg1_xyz
sh ../generate_result.sh
cd ../rgbd_dataset_freiburg1_rpy
sh ../generate_result.sh
cd ../rgbd_dataset_freiburg1_360
sh ../generate_result.sh
cd ../rgbd_dataset_freiburg1_floor
sh ../generate_result.sh
cd ../rgbd_dataset_freiburg1_desk
sh ../generate_result.sh
cd ../rgbd_dataset_freiburg1_desk2
sh ../generate_result.sh
cd ../rgbd_dataset_freiburg1_room
sh ../generate_result.sh
cd ..
