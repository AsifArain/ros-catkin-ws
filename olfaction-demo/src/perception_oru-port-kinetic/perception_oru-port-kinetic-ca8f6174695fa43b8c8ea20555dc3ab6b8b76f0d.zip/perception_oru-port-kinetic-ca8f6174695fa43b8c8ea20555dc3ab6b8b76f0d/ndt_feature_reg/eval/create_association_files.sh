# Create association files
`pwd`/associate.py rgbd_dataset_freiburg1_xyz/rgb.txt rgbd_dataset_freiburg1_xyz/depth.txt > rgbd_dataset_freiburg1_xyz/association.txt

`pwd`/associate.py rgbd_dataset_freiburg1_rpy/rgb.txt rgbd_dataset_freiburg1_rpy/depth.txt > rgbd_dataset_freiburg1_rpy/association.txt

`pwd`/associate.py rgbd_dataset_freiburg1_360/rgb.txt rgbd_dataset_freiburg1_360/depth.txt > rgbd_dataset_freiburg1_360/association.txt

`pwd`/associate.py rgbd_dataset_freiburg1_floor/rgb.txt rgbd_dataset_freiburg1_floor/depth.txt > rgbd_dataset_freiburg1_floor/association.txt

`pwd`/associate.py rgbd_dataset_freiburg1_desk/rgb.txt rgbd_dataset_freiburg1_desk/depth.txt > rgbd_dataset_freiburg1_desk/association.txt

`pwd`/associate.py rgbd_dataset_freiburg1_desk2/rgb.txt rgbd_dataset_freiburg1_desk2/depth.txt > rgbd_dataset_freiburg1_desk2/association.txt

`pwd`/associate.py rgbd_dataset_freiburg1_room/rgb.txt rgbd_dataset_freiburg1_room/depth.txt > rgbd_dataset_freiburg1_room/association.txt
